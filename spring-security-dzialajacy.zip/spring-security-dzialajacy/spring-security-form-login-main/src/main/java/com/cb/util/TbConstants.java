package com.cb.util;

public class TbConstants {
    public static interface Roles {
        String USER = "ROLE_USER";
        String ADMIN = "ROLE_ADMIN";
    }
}
