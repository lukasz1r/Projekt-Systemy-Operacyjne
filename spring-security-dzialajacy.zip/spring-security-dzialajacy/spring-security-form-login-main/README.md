### Prerequisite

Create a database in MySql with the help of below mentioned query:

``` CREATE SCHEMA `spring-security-form-login`; ```

Documentation: https://www.codeburps.com/post/spring-boot-form-login

